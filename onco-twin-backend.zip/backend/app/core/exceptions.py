class NotFoundError(Exception):
    """Raised by services when a requested aggregate doesn't exist (or is
    soft-deleted). Translated to a 404 by the handler registered in main.py,
    so routers never need their own try/except for this case."""
