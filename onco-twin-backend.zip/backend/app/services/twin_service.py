"""Business logic for the Digital Twin: resync/restore/archive side effects
(new TwinVersion/TwinSnapshotRow/PredictionRun rows, timeline events, audit
logging). Routers call into this and stay thin; data access goes through
TwinRepository."""

from datetime import datetime, timezone

from sqlalchemy.orm import Session

from app import models, schemas
from app.core.exceptions import NotFoundError
from app.deps import log_audit
from app.ml.model import predict_from_patient
from app.repositories.twin_repository import TwinRepository
from app.serializers import patient_to_schema


def _now() -> str:
    return datetime.now(timezone.utc).isoformat()


class TwinService:
    def __init__(self, db: Session):
        self.db = db
        self.repo = TwinRepository(db)

    def list_twins(self) -> list[schemas.Patient]:
        return [patient_to_schema(p) for p in self.repo.list_patients()]

    def list_versions(self, patient_id: str) -> list[schemas.TwinVersion]:
        rows = self.repo.list_versions(patient_id)
        return [
            schemas.TwinVersion(version=r.version, created_at=r.created_at, status=r.status, author=r.author,
                                 summary=r.summary, tumor_size_mm=r.tumor_size_mm, survival=r.survival,
                                 risk=r.risk, model=r.model)
            for r in rows
        ]

    def list_snapshots(self, patient_id: str) -> list[schemas.TwinSnapshot]:
        rows = self.repo.list_snapshots(patient_id)
        return [schemas.TwinSnapshot(id=r.id, version=r.version, taken_at=r.taken_at, trigger=r.trigger, size=r.size) for r in rows]

    def resync(self, patient_id: str, user: models.User) -> str:
        p = self.repo.get_patient(patient_id)
        if not p:
            raise NotFoundError("Patient not found")
        p.twin_status = "Recalculating"
        self.db.commit()

        result = predict_from_patient({
            "stage": p.stage, "grade": p.grade, "ki67": p.ki67, "nodesInvolved": p.nodes_involved,
            "tumorSizeMm": p.tumor_size_mm, "erStatus": p.er_status, "prStatus": p.pr_status,
            "her2Status": p.her2_status, "age": p.age,
        })
        p.risk = result["risk"]
        p.survival_probability = result["survival"]
        p.twin_status = "Synced"
        p.last_updated = _now()

        version = self.repo.next_version_label(patient_id)
        self.repo.add(models.TwinVersion(
            patient_id=patient_id, version=version, author=user.name,
            summary=f"Resynced from latest clinical data by {user.name}.",
            tumor_size_mm=p.tumor_size_mm, survival=p.survival_probability, risk=p.risk,
            model="OncoTwin Malignancy Risk Model", snapshot=patient_to_schema(p).model_dump(by_alias=False),
        ))
        self.repo.add(models.TwinSnapshotRow(patient_id=patient_id, version=version, trigger="manual resync", size="12 KB"))
        self.repo.add(models.PredictionRun(
            patient_id=patient_id, twin_version=version, model="OncoTwin Malignancy Risk Model",
            survival=result["survival"], recurrence=result["recurrence"], response=result["response"],
            confidence=result["confidence"], status=result["status"],
        ))
        self.db.commit()
        log_audit(self.db, actor=user.email, action="resync_twin", target=p.name)
        return version

    def restore(self, patient_id: str, version: str, user: models.User) -> None:
        tv = self.repo.get_version(patient_id, version)
        p = self.repo.get_patient(patient_id)
        if not tv or not p:
            raise NotFoundError("Twin version not found")
        snap = tv.snapshot or {}
        for field in ("stage", "tumor_size_mm", "er_status", "pr_status", "her2_status", "ki67", "grade",
                      "nodes_involved", "current_treatment", "status", "risk", "survival_probability"):
            if field in snap:
                setattr(p, field, snap[field])
        p.twin_status = "Synced"
        p.last_updated = _now()
        self.repo.add(models.TimelineEvent(
            patient_id=patient_id, date=p.last_updated, title=f"Restored to {version}",
            detail=f"Digital twin restored by {user.name}.", kind="note",
        ))
        self.db.commit()
        log_audit(self.db, actor=user.email, action="restore_twin", target=f"{p.name}:{version}")

    def archive(self, patient_id: str, user: models.User) -> None:
        p = self.repo.get_patient(patient_id)
        if not p:
            raise NotFoundError("Patient not found")
        p.twin_status = "Stale"
        latest = self.repo.latest_version(patient_id)
        if latest:
            latest.status = "Archived"
        self.db.commit()
        log_audit(self.db, actor=user.email, action="archive_twin", target=p.name)
