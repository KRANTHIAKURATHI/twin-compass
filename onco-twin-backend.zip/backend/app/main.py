from contextlib import asynccontextmanager
from pathlib import Path

from alembic import command
from alembic.config import Config
from fastapi import FastAPI, Request
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse

from app.core.config import get_settings
from app.core.database import SessionLocal
from app.core.exceptions import NotFoundError
from app.ml.train import MODEL_PATH, train
from app.routers import (
    admin,
    analytics,
    appointments,
    auth,
    documents,
    notifications,
    ocr,
    patients,
    predictions,
    reports,
    research,
    search,
    simulations,
    treatment,
    twins,
)
from app.seed import seed

settings = get_settings()

BACKEND_ROOT = Path(__file__).resolve().parent.parent


def _run_migrations() -> None:
    """Applies pending Alembic revisions on startup so schema changes are
    always tracked, instead of the previous ad-hoc `create_all()`."""
    alembic_cfg = Config(str(BACKEND_ROOT / "alembic.ini"))
    alembic_cfg.set_main_option("script_location", str(BACKEND_ROOT / "app" / "migrations"))
    command.upgrade(alembic_cfg, "head")


@asynccontextmanager
async def lifespan(app: FastAPI):
    _run_migrations()
    if not MODEL_PATH.exists():
        train()
    db = SessionLocal()
    try:
        seed(db)
    finally:
        db.close()
    yield


app = FastAPI(title="OncoTwin API", version="1.0.0", lifespan=lifespan)


@app.exception_handler(NotFoundError)
def handle_not_found(request: Request, exc: NotFoundError):
    return JSONResponse(status_code=404, content={"detail": str(exc) or "Not found"})

app.add_middleware(
    CORSMiddleware,
    allow_origins=settings.cors_origin_list,
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

for router in (
    auth.router, patients.router, twins.router, predictions.router, simulations.router,
    documents.router, ocr.router, reports.router, appointments.router, treatment.router,
    notifications.router, analytics.router, admin.router, research.router, search.router,
):
    app.include_router(router)


@app.get("/health")
def health():
    return {"status": "ok"}
