from fastapi import APIRouter, Depends
from sqlalchemy.orm import Session

from app import models, schemas
from app.core.database import get_db
from app.deps import require_roles

router = APIRouter(prefix="/admin", tags=["admin"])
_admin_only = require_roles("admin")


@router.get("/hospitals", response_model=list[schemas.Hospital])
def hospitals(db: Session = Depends(get_db), _user: models.User = Depends(_admin_only)):
    rows = db.query(models.Hospital).all()
    return [schemas.Hospital(id=h.id, name=h.name, city=h.city, beds=h.beds, doctors=h.doctors, patients=h.patients, status=h.status) for h in rows]


@router.get("/doctors", response_model=list[schemas.DoctorProfile])
def doctors(db: Session = Depends(get_db), _user: models.User = Depends(_admin_only)):
    rows = db.query(models.User).filter(models.User.role == "doctor").all()
    result = []
    for d in rows:
        patient_count = db.query(models.Patient).filter(models.Patient.created_by == d.id).count()
        result.append(schemas.DoctorProfile(id=d.id, name=d.name, dept=d.department or "General Oncology",
                                             hospital=d.hospital or "", patients=patient_count, status=d.status))
    return result


@router.get("/departments", response_model=list[schemas.Department])
def departments(db: Session = Depends(get_db), _user: models.User = Depends(_admin_only)):
    rows = db.query(models.Department).all()
    return [schemas.Department(id=d.id, name=d.name, head=d.head, staff=d.staff, active_cases=d.active_cases) for d in rows]


@router.get("/users", response_model=list[schemas.PlatformUser])
def users(db: Session = Depends(get_db), _user: models.User = Depends(_admin_only)):
    rows = db.query(models.User).all()
    return [schemas.PlatformUser(id=u.id, name=u.name, email=u.email, role=u.role, last_active=u.last_active, status=u.status) for u in rows]


@router.get("/audit-logs", response_model=list[schemas.AuditLogEntry])
def audit_logs(db: Session = Depends(get_db), _user: models.User = Depends(_admin_only)):
    rows = db.query(models.AuditLogEntry).order_by(models.AuditLogEntry.time.desc()).limit(500).all()
    return [schemas.AuditLogEntry(id=a.id, time=a.time, actor=a.actor, action=a.action, target=a.target, ip=a.ip) for a in rows]


@router.get("/permissions", response_model=list[schemas.PermissionRow])
def permissions(db: Session = Depends(get_db), _user: models.User = Depends(_admin_only)):
    rows = db.query(models.PermissionRow).all()
    return [schemas.PermissionRow(capability=p.capability, doctor=p.doctor, patient=p.patient, technician=p.technician, admin=p.admin) for p in rows]
