from datetime import datetime, timedelta, timezone

from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session

from app import models, schemas
from app.core.database import get_db
from app.core.security import (
    create_access_token,
    generate_reset_token,
    hash_password,
    verify_password,
)
from app.deps import get_current_user, log_audit

router = APIRouter(prefix="/auth", tags=["auth"])


def _auth_user(u: models.User) -> schemas.AuthUser:
    return schemas.AuthUser(
        id=u.id, name=u.name, email=u.email, role=u.role, title=u.title,
        hospital=u.hospital, avatar_url=u.avatar_url,
    )


@router.post("/login", response_model=schemas.AuthSession)
def login(payload: schemas.Credentials, db: Session = Depends(get_db)):
    user = db.query(models.User).filter(models.User.email == payload.email).first()
    if not user or not verify_password(payload.password, user.password_hash):
        raise HTTPException(status_code=401, detail="Invalid email or password")
    token, expires_at = create_access_token(user.id, user.role)
    user.last_active = datetime.now(timezone.utc).isoformat()
    db.commit()
    log_audit(db, actor=user.email, action="login", target="auth")
    return schemas.AuthSession(user=_auth_user(user), access_token=token, expires_at=expires_at.isoformat())


@router.post("/register", response_model=schemas.MutationResult[schemas.AuthUser])
def register(payload: schemas.RegisterPayload, db: Session = Depends(get_db)):
    if db.query(models.User).filter(models.User.email == payload.email).first():
        raise HTTPException(status_code=409, detail="An account with this email already exists")
    user = models.User(
        name=payload.name,
        email=payload.email,
        password_hash=hash_password(payload.password),
        role=payload.role,
        hospital=payload.hospital,
        specialization=payload.specialization,
    )
    db.add(user)
    db.commit()
    db.refresh(user)
    log_audit(db, actor=user.email, action="register", target="auth")
    return schemas.MutationResult(ok=True, data=_auth_user(user), message="Account created")


@router.post("/logout", response_model=schemas.MutationResult)
def logout(user: models.User = Depends(get_current_user), db: Session = Depends(get_db)):
    log_audit(db, actor=user.email, action="logout", target="auth")
    return schemas.MutationResult(ok=True, message="Logged out")


@router.post("/forgot-password", response_model=schemas.MutationResult)
def forgot_password(payload: schemas.ForgotPasswordPayload, db: Session = Depends(get_db)):
    user = db.query(models.User).filter(models.User.email == payload.email).first()
    if user:
        token = generate_reset_token()
        db.add(models.PasswordResetToken(
            user_id=user.id, token=token,
            expires_at=datetime.utcnow() + timedelta(hours=1),
        ))
        db.commit()
        # No transactional email provider is wired up yet; the token is
        # deliberately not leaked to the response outside of dev mode.
        from app.core.config import get_settings
        if get_settings().environment == "development":
            return schemas.MutationResult(
                ok=True,
                message="Reset token generated (dev mode — shown because no email provider is configured)",
                data={"resetToken": token},
            )
    return schemas.MutationResult(ok=True, message="If that email exists, a reset link has been sent")


@router.post("/reset-password", response_model=schemas.MutationResult)
def reset_password(payload: schemas.ResetPasswordPayload, db: Session = Depends(get_db)):
    record = (
        db.query(models.PasswordResetToken)
        .filter(models.PasswordResetToken.token == payload.token, models.PasswordResetToken.used.is_(False))
        .first()
    )
    if not record or record.expires_at < datetime.utcnow():
        raise HTTPException(status_code=400, detail="Reset token is invalid or has expired")
    user = db.get(models.User, record.user_id)
    if not user:
        raise HTTPException(status_code=400, detail="Reset token is invalid or has expired")
    user.password_hash = hash_password(payload.password)
    record.used = True
    db.commit()
    log_audit(db, actor=user.email, action="reset_password", target="auth")
    return schemas.MutationResult(ok=True, message="Password updated")


@router.get("/me", response_model=schemas.AuthUser)
def me(user: models.User = Depends(get_current_user)):
    return _auth_user(user)
