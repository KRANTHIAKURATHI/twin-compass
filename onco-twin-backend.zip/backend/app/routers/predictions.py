from datetime import datetime, timezone

from fastapi import APIRouter, Body, Depends, HTTPException
from sqlalchemy.orm import Session

from app import models, schemas
from app.core.database import get_db
from app.deps import get_current_user, log_audit
from app.ml.model import feature_importances, predict_from_patient

router = APIRouter(prefix="/predictions", tags=["predictions"])


def _patient_fields(p: models.Patient) -> dict:
    return {
        "stage": p.stage, "grade": p.grade, "ki67": p.ki67, "nodesInvolved": p.nodes_involved,
        "tumorSizeMm": p.tumor_size_mm, "erStatus": p.er_status, "prStatus": p.pr_status,
        "her2Status": p.her2_status, "age": p.age,
    }


def _latest_twin_version(db: Session, patient_id: str) -> str:
    tv = db.query(models.TwinVersion).filter(models.TwinVersion.patient_id == patient_id).order_by(models.TwinVersion.created_at.desc()).first()
    return tv.version if tv else "v1"


@router.get("/{patient_id}", response_model=schemas.PredictionRun | None)
def for_patient(patient_id: str, db: Session = Depends(get_db), _user: models.User = Depends(get_current_user)):
    run = db.query(models.PredictionRun).filter(models.PredictionRun.patient_id == patient_id).order_by(models.PredictionRun.date.desc()).first()
    if not run:
        return None
    return schemas.PredictionRun(id=run.id, date=run.date, twin_version=run.twin_version, model=run.model,
                                  survival=run.survival, recurrence=run.recurrence, response=run.response,
                                  confidence=run.confidence, status=run.status)


@router.get("/{patient_id}/history", response_model=list[schemas.PredictionRun])
def history(patient_id: str, db: Session = Depends(get_db), _user: models.User = Depends(get_current_user)):
    rows = db.query(models.PredictionRun).filter(models.PredictionRun.patient_id == patient_id).order_by(models.PredictionRun.date.desc()).all()
    return [schemas.PredictionRun(id=r.id, date=r.date, twin_version=r.twin_version, model=r.model, survival=r.survival,
                                   recurrence=r.recurrence, response=r.response, confidence=r.confidence, status=r.status) for r in rows]


@router.get("/{patient_id}/confidence-trend", response_model=list[schemas.ConfidencePoint])
def confidence_trend(patient_id: str, db: Session = Depends(get_db), _user: models.User = Depends(get_current_user)):
    rows = db.query(models.PredictionRun).filter(models.PredictionRun.patient_id == patient_id).order_by(models.PredictionRun.date.asc()).all()
    return [schemas.ConfidencePoint(date=r.date, confidence=r.confidence) for r in rows]


@router.get("/{patient_id}/explainability", response_model=list[schemas.FeatureImportance])
def explain(patient_id: str, db: Session = Depends(get_db), _user: models.User = Depends(get_current_user)):
    p = db.get(models.Patient, patient_id)
    if not p:
        raise HTTPException(status_code=404, detail="Patient not found")
    rows = feature_importances(_patient_fields(p))
    return [schemas.FeatureImportance(**r) for r in rows]


@router.post("/run", response_model=schemas.MutationResult[schemas.PredictionRun])
def run(patient_id: str = Body(..., embed=True, alias="patientId"), db: Session = Depends(get_db), user: models.User = Depends(get_current_user)):
    p = db.get(models.Patient, patient_id)
    if not p:
        raise HTTPException(status_code=404, detail="Patient not found")
    result = predict_from_patient(_patient_fields(p))
    twin_version = _latest_twin_version(db, patient_id)
    run_row = models.PredictionRun(
        patient_id=patient_id, twin_version=twin_version, model="OncoTwin Malignancy Risk Model",
        survival=result["survival"], recurrence=result["recurrence"], response=result["response"],
        confidence=result["confidence"], status=result["status"],
    )
    p.risk = result["risk"]
    p.survival_probability = result["survival"]
    p.last_updated = datetime.now(timezone.utc).isoformat()
    db.add(run_row)
    db.commit()
    db.refresh(run_row)
    log_audit(db, actor=user.email, action="run_prediction", target=p.name)
    return schemas.MutationResult(
        ok=True, message="Prediction complete",
        data=schemas.PredictionRun(id=run_row.id, date=run_row.date, twin_version=run_row.twin_version,
                                    model=run_row.model, survival=run_row.survival, recurrence=run_row.recurrence,
                                    response=run_row.response, confidence=run_row.confidence, status=run_row.status),
    )
