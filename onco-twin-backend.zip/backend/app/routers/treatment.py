from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session

from app import models, schemas
from app.core.database import get_db
from app.deps import get_current_user
from app.ml.regimens import REGIMENS

router = APIRouter(prefix="/patients", tags=["treatment"])

_DEFAULT_MEDICATIONS = {
    "AC-T (Doxorubicin/Cyclophosphamide + Paclitaxel)": [
        {"name": "Doxorubicin", "dose": "60 mg/m^2 IV", "schedule": "Every 2 weeks x4"},
        {"name": "Paclitaxel", "dose": "80 mg/m^2 IV", "schedule": "Weekly x12"},
    ],
    "TC (Docetaxel/Cyclophosphamide)": [
        {"name": "Docetaxel", "dose": "75 mg/m^2 IV", "schedule": "Every 3 weeks x4"},
        {"name": "Cyclophosphamide", "dose": "600 mg/m^2 IV", "schedule": "Every 3 weeks x4"},
    ],
    "Endocrine Therapy (Tamoxifen/AI)": [
        {"name": "Tamoxifen", "dose": "20 mg PO", "schedule": "Daily x5 years"},
    ],
    "HER2-Targeted Therapy (Trastuzumab + Pertuzumab)": [
        {"name": "Trastuzumab", "dose": "6 mg/kg IV", "schedule": "Every 3 weeks x17"},
        {"name": "Pertuzumab", "dose": "420 mg IV", "schedule": "Every 3 weeks x17"},
    ],
    "Neoadjuvant Chemotherapy + Surgery": [
        {"name": "Per regimen", "dose": "As prescribed", "schedule": "Pre-operative course"},
    ],
    "Active Surveillance": [],
}

_SIDE_EFFECTS_BY_TOXICITY = [
    (0.6, [{"name": "Neutropenia", "grade": "Grade 2", "advice": "Monitor CBC weekly; report fever immediately."}]),
    (0.3, [{"name": "Fatigue", "grade": "Grade 1", "advice": "Prioritize rest; light activity as tolerated."}]),
    (0.0, [{"name": "Mild nausea", "grade": "Grade 1", "advice": "Take antiemetic as prescribed with meals."}]),
]


def _side_effects_for(regimen: str) -> list[dict]:
    toxicity = REGIMENS.get(regimen, {}).get("toxicity", 0.2)
    for threshold, effects in _SIDE_EFFECTS_BY_TOXICITY:
        if toxicity >= threshold:
            return effects
    return []


@router.get("/{patient_id}/treatment-plan", response_model=schemas.TreatmentPlan)
def plan(patient_id: str, db: Session = Depends(get_db), _user: models.User = Depends(get_current_user)):
    patient = db.get(models.Patient, patient_id)
    if not patient:
        raise HTTPException(status_code=404, detail="Patient not found")

    row = db.query(models.TreatmentPlanRow).filter(models.TreatmentPlanRow.patient_id == patient_id).first()
    if not row:
        regimen = patient.current_treatment if patient.current_treatment in REGIMENS else "Active Surveillance"
        profile = REGIMENS.get(regimen, {})
        row = models.TreatmentPlanRow(
            patient_id=patient_id, regimen=regimen, cycle=1,
            total_cycles=max(int(profile.get("recovery_weeks", 12) / 3), 1),
            started_on=patient.diagnosed_on, next_dose=patient.last_updated, adherence=1.0,
            side_effects=_side_effects_for(regimen), medications=_DEFAULT_MEDICATIONS.get(regimen, []),
        )
        db.add(row)
        db.commit()
        db.refresh(row)

    return schemas.TreatmentPlan(
        regimen=row.regimen, cycle=row.cycle, total_cycles=row.total_cycles, started_on=row.started_on,
        next_dose=row.next_dose, adherence=row.adherence,
        side_effects=[schemas.SideEffect(**s) for s in (row.side_effects or [])],
        medications=[schemas.Medication(**m) for m in (row.medications or [])],
    )
