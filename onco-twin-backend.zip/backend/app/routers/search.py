from fastapi import APIRouter, Depends, Query
from sqlalchemy.orm import Session

from app import models
from app.core.database import get_db
from app.deps import get_current_user

router = APIRouter(prefix="/search", tags=["search"])


@router.get("")
def global_search(q: str = Query(..., min_length=1), db: Session = Depends(get_db), _user: models.User = Depends(get_current_user)):
    like = f"%{q}%"
    patients = db.query(models.Patient).filter(models.Patient.name.ilike(like)).limit(10).all()
    documents = db.query(models.DocumentRecord).filter(models.DocumentRecord.name.ilike(like)).limit(10).all()
    reports = db.query(models.SavedReport).filter(models.SavedReport.title.ilike(like)).limit(10).all()

    return {
        "patients": [{"id": p.id, "name": p.name, "type": "patient"} for p in patients],
        "documents": [{"id": d.id, "name": d.name, "type": "document"} for d in documents],
        "reports": [{"id": r.id, "name": r.title, "type": "report"} for r in reports],
    }
