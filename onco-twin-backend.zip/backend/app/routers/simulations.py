import uuid

from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session

from app import models, schemas
from app.core.database import get_db
from app.deps import get_current_user, log_audit
from app.ml.regimens import simulate_all

router = APIRouter(prefix="/simulations", tags=["simulations"])


def _patient_fields(p: models.Patient) -> dict:
    return {
        "stage": p.stage, "grade": p.grade, "ki67": p.ki67, "nodesInvolved": p.nodes_involved,
        "tumorSizeMm": p.tumor_size_mm, "erStatus": p.er_status, "prStatus": p.pr_status,
        "her2Status": p.her2_status, "age": p.age,
    }


def _row_to_schema(r: models.SimulationRun) -> schemas.SimulationRun:
    return schemas.SimulationRun(id=r.id, date=r.date, patient=r.patient_name, patient_id=r.patient_id,
                                  twin_version=r.twin_version, model=r.model, selected=r.selected,
                                  compared=r.compared or [], decision=r.decision, decided_by=r.decided_by,
                                  notes=r.notes or "", survival=r.survival, response=r.response, confidence=r.confidence)


@router.get("", response_model=list[schemas.SimulationRun])
def list_simulations(db: Session = Depends(get_db), _user: models.User = Depends(get_current_user)):
    rows = db.query(models.SimulationRun).order_by(models.SimulationRun.date.desc()).all()
    return [_row_to_schema(r) for r in rows]


@router.get("/{sim_id}", response_model=schemas.SimulationRun | None)
def get_simulation(sim_id: str, db: Session = Depends(get_db), _user: models.User = Depends(get_current_user)):
    r = db.get(models.SimulationRun, sim_id)
    return _row_to_schema(r) if r else None


@router.post("/run")
def run_simulation(payload: dict, db: Session = Depends(get_db), _user: models.User = Depends(get_current_user)):
    patient_id = payload.get("patientId")
    p = db.get(models.Patient, patient_id) if patient_id else None
    if not p:
        raise HTTPException(status_code=404, detail="Patient not found")

    scenarios = simulate_all(_patient_fields(p))
    scenario_schemas = [
        schemas.Scenario(
            id=str(uuid.uuid4()), name=s["regimen"], regimen=s["regimen"],
            predicted_response=s["predicted_response"], tumor_change=s["tumor_change"], risk=s["risk"],
            confidence=s["confidence"], survival5y=s["survival5y"], side_effect_risk=s["side_effect_risk"],
            recovery_weeks=s["recovery_weeks"], recommended=s["recommended"],
        )
        for s in scenarios
    ]
    return {"patientId": patient_id, "scenarios": [sc.model_dump(by_alias=True) for sc in scenario_schemas]}


@router.post("", response_model=schemas.MutationResult[schemas.SimulationRun])
def save_simulation(draft: schemas.ScenarioDraft, patient_id: str | None = None, db: Session = Depends(get_db), user: models.User = Depends(get_current_user)):
    p = db.get(models.Patient, patient_id) if patient_id else db.query(models.Patient).first()
    if not p:
        raise HTTPException(status_code=404, detail="No patient available to attach this simulation to")
    result = simulate_all(_patient_fields(p))
    match = next((s for s in result if s["regimen"] == draft.regimen), result[0])
    row = models.SimulationRun(
        patient_id=p.id, patient_name=p.name, twin_version="v1", model="OncoTwin Malignancy Risk Model",
        selected=draft.regimen, compared=[s["regimen"] for s in result if s["regimen"] != draft.regimen],
        decision="Under review", decided_by=user.name, notes=draft.notes,
        survival=match["survival5y"], response=match["predicted_response"] / 100, confidence=match["confidence"],
        scenarios=result,
    )
    db.add(row)
    db.commit()
    db.refresh(row)
    log_audit(db, actor=user.email, action="save_simulation", target=p.name)
    return schemas.MutationResult(ok=True, data=_row_to_schema(row), message="Scenario saved")


@router.post("/{sim_id}/duplicate", response_model=schemas.MutationResult[schemas.SimulationRun])
def duplicate(sim_id: str, db: Session = Depends(get_db), user: models.User = Depends(get_current_user)):
    original = db.get(models.SimulationRun, sim_id)
    if not original:
        raise HTTPException(status_code=404, detail="Simulation not found")
    clone = models.SimulationRun(
        patient_id=original.patient_id, patient_name=original.patient_name, twin_version=original.twin_version,
        model=original.model, selected=original.selected, compared=original.compared, decision="Under review",
        decided_by=user.name, notes=f"Duplicated from {original.id}", survival=original.survival,
        response=original.response, confidence=original.confidence, scenarios=original.scenarios,
    )
    db.add(clone)
    db.commit()
    db.refresh(clone)
    return schemas.MutationResult(ok=True, data=_row_to_schema(clone), message="Scenario duplicated")


@router.post("/{sim_id}/promote", response_model=schemas.MutationResult)
def promote(sim_id: str, payload: dict | None = None, db: Session = Depends(get_db), user: models.User = Depends(get_current_user)):
    row = db.get(models.SimulationRun, sim_id)
    if not row:
        raise HTTPException(status_code=404, detail="Simulation not found")
    row.decision = "Promoted to plan"
    row.notes = (payload or {}).get("notes", row.notes)

    from app.ml.regimens import REGIMENS
    profile = REGIMENS.get(row.selected, {})
    plan = db.query(models.TreatmentPlanRow).filter(models.TreatmentPlanRow.patient_id == row.patient_id).first()
    if not plan:
        plan = models.TreatmentPlanRow(patient_id=row.patient_id)
        db.add(plan)
    plan.regimen = row.selected
    plan.cycle = 1
    plan.total_cycles = max(int(profile.get("recovery_weeks", 12) / 3), 1)
    plan.adherence = 1.0

    patient = db.get(models.Patient, row.patient_id)
    if patient:
        patient.current_treatment = row.selected

    db.commit()
    log_audit(db, actor=user.email, action="promote_simulation", target=row.selected)
    return schemas.MutationResult(ok=True, message=f"{row.selected} promoted to treatment plan")
