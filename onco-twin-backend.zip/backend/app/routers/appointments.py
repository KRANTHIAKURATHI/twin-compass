from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session

from app import models, schemas
from app.core.database import get_db
from app.deps import get_current_user, log_audit

router = APIRouter(prefix="/appointments", tags=["appointments"])


def _row_to_schema(a: models.Appointment) -> schemas.Appointment:
    return schemas.Appointment(id=a.id, title=a.title, doctor=a.doctor, date=a.date, time=a.time, location=a.location, status=a.status)


@router.get("", response_model=list[schemas.Appointment])
def list_appointments(db: Session = Depends(get_db), _user: models.User = Depends(get_current_user)):
    return [_row_to_schema(a) for a in db.query(models.Appointment).order_by(models.Appointment.date.asc()).all()]


@router.post("", response_model=schemas.MutationResult[schemas.Appointment])
def create(payload: schemas.AppointmentInput, db: Session = Depends(get_db), user: models.User = Depends(get_current_user)):
    row = models.Appointment(title=payload.title, doctor=payload.doctor, date=payload.date, time=payload.time,
                              location=payload.location, patient_id=payload.patient_id, status="Scheduled")
    db.add(row)
    db.commit()
    db.refresh(row)
    log_audit(db, actor=user.email, action="create_appointment", target=row.title)
    return schemas.MutationResult(ok=True, data=_row_to_schema(row), message="Appointment scheduled")


@router.post("/{appointment_id}/cancel", response_model=schemas.MutationResult)
def cancel(appointment_id: str, db: Session = Depends(get_db), user: models.User = Depends(get_current_user)):
    row = db.get(models.Appointment, appointment_id)
    if not row:
        raise HTTPException(status_code=404, detail="Appointment not found")
    row.status = "Cancelled"
    db.commit()
    log_audit(db, actor=user.email, action="cancel_appointment", target=row.title)
    return schemas.MutationResult(ok=True, message="Appointment cancelled")
